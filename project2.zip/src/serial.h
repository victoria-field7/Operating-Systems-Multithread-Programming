#ifndef __SERIAL_H__
#define __SERIAL_H__

void compress_directory(char *directory_name);

#endif